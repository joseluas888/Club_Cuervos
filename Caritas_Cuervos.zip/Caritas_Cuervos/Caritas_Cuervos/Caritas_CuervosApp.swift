//
//  Caritas_CuervosApp.swift
//  Caritas_Cuervos
//
//  Created by Alumno on 12/10/23.
//

import SwiftUI

@main
struct Caritas_CuervosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
