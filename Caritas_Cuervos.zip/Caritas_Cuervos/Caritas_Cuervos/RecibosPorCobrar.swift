//
//  RecibosPorCobrar.swift
//  Caritas_Cuervos
//
//  Created by Alumno on 06/11/23.
//

import SwiftUI
import CoreMotion

struct RecibosPorCobrar: View {
    @StateObject var modalState = ModalState()
    
    @Binding var fichas_prueba:[Ficha]
    @Binding var fichas_cobradas:[Ficha]
    @State var motionManager: CMMotionManager!
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(alignment: .center){
            HStack{Spacer()}
                .frame(width: 500.0)
                .background(blanco)
            ZStack{
                HeaderPrincipalView()
                HStack{
                    Spacer()
                    Button{
                        dismiss()
                    } label: {
                        Image(systemName: "rectangle.portrait.and.arrow.forward")
                            .resizable(resizingMode: .stretch)
                            .aspectRatio(contentMode: .fit)
                            .foregroundColor(azul)
                            .padding(.leading, 20.0)
                            .frame(width: 60.0)
                    }
                    .padding(.bottom, 35.0)
                    .padding(.trailing, 25.0)
                }
            }
            List(){
                ForEach(fichas_prueba) { ficha in
                    ElementosPrincipalView(modalState: self.modalState, fichas_porCobrar: self.$fichas_prueba, fichas_cobradas: self.$fichas_cobradas, direccion: ficha.f_direccion, nombre: ficha.f_nombre, folio: ficha.id, cantidad: ficha.f_cantidad, ref: ficha.f_referencias, detalles: ficha.f_detalles, telFijo: ficha.f_telPri, telExtra: ficha.f_telSec, telCelular: ficha.f_telCel)
                }
                .onMove(perform: move)
                .listRowBackground(blanco)
            }
            .background(blanco)
            .listStyle(.plain)
            Spacer()
        }
        .background(blanco)
        .navigationBarBackButtonHidden(true)
        .onAppear{
            motionManager = CMMotionManager()
            motionManager.startAccelerometerUpdates()
            if(fichas_prueba.count == 0){
                fetchRecibos(forUserID: 1) { recibos in
                    if let recibos = recibos {
                        fichas_prueba = recibos.map { recibo in
                            return Ficha(id: recibo.folioRecibo, f_direccion: "\(recibo.calle) \(recibo.numero), \(recibo.municipio)",f_nombre: "\(recibo.nombre) \(recibo.apellidoPaterno) \(recibo.apellidoMaterno)", f_folio: "\(recibo.folioRecibo)", f_cantidad: "\(recibo.monto)", f_referencias: recibo.referencias, f_detalles: recibo.detalles, f_telCel: "\(recibo.telefonoCelular)", f_telPri: "\(recibo.telefonoPrincipal)", f_telSec: "\(recibo.telefonoSecundario)", f_recibido: false, f_comentario: "Ninguno")
                        }
                    }
                }
                UserDefaults.standard.set(fichas_prueba, forKey: "OrdenDeFichas")
            }
            if let accelerometerData = motionManager.accelerometerData {
                if accelerometerData.acceleration.y > 1.0{
                    fichas_prueba.removeAll()
                }
            }
        }
    }
    
    func move(from source: IndexSet, to destination: Int) {
        fichas_prueba.move(fromOffsets: source, toOffset: destination)
    }
}

struct RecibosPorCobrar_Previews: PreviewProvider {
    static var previews: some View {
        @State var tempVar:[Ficha] = []
        @State var tempVar2:[Ficha] = []
        RecibosPorCobrar(fichas_prueba: $tempVar, fichas_cobradas: $tempVar2)
    }
}
