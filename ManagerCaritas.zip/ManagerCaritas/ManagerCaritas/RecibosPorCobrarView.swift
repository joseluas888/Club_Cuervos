//
//  RecibosPorCobrarView.swift
//  ManagerCaritas
//
//  Created by Alumno on 23/11/23.
//

import SwiftUI

struct RecibosPorCobrarView: View {
    var body: some View {
        Text("Recibos por cobrar")
    }
}

struct RecibosPorCobrarView_Previews: PreviewProvider {
    static var previews: some View {
        RecibosPorCobrarView()
    }
}
