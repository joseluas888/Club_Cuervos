//
//  RecibosYaCobradosView.swift
//  ManagerCaritas
//
//  Created by Alumno on 10/11/23.
//


import SwiftUI

struct RecibosYaCobradosView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}


struct RecibosYaCobradosView_Previews: PreviewProvider {
    static var previews: some View {
        RecibosYaCobradosView()
    }
}

