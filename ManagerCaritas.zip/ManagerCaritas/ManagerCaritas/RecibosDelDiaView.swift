//
//  RecibosDelDiaView.swift
//  ManagerCaritas
//
//  Created by Alumno on 10/11/23.
//

import SwiftUI

struct RecibosDelDiaView: View {
    var body: some View {
        VStack{
            Text("Recibos de Dia!")
            
        }
        
    }
}

struct RecibosDelDiaView_Previews: PreviewProvider {
    static var previews: some View {
        RecibosDelDiaView()
    }
}
