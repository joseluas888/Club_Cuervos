//
//  TabRecibosView.swift
//  ManagerCaritas
//
//  Created by Alumno on 23/11/23.
//

import SwiftUI

struct TabRecibosView: View {
    var body: some View {
        VStack{
            TabView{
                RecibosPorCobrarView()
                    .tabItem {Label("Por cobrar", systemImage: "dollarsign.circle.fill")}
                RecibosPagadosView()
                    .tabItem {Label("Pagados", systemImage: "checkmark.circle.fill")}
                RecibosNoPagadosView()
                    .tabItem {Label("No pagados", systemImage: "xmark.circle.fill")}
            }
        }
        //.navigationBarBackButtonHidden(true)
    }
}

struct TabRecibosView_Previews: PreviewProvider {
    static var previews: some View {
        TabRecibosView()
    }
}
