//
//  DashboardsView.swift
//  ManagerCaritas
//
//  Created by Alumno on 16/11/23.
//

import SwiftUI

struct DashboardsView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct DashboardsView_Previews: PreviewProvider {
    static var previews: some View {
        DashboardsView()
    }
}
