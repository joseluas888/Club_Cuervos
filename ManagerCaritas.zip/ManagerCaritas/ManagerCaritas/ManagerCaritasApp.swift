//
//  ManagerCaritasApp.swift
//  ManagerCaritas
//
//  Created by Alumno on 05/11/23.
//

import SwiftUI

@main
struct ManagerCaritasApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
