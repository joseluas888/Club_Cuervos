//
//  RecibosComentadosView.swift
//  ManagerCaritas
//
//  Created by Alumno on 10/11/23.
//

import SwiftUI

struct RecibosComentadosView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}


