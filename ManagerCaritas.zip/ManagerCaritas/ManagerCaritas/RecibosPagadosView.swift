//
//  RecibosPagadosView.swift
//  ManagerCaritas
//
//  Created by Alumno on 23/11/23.
//

import SwiftUI

struct RecibosPagadosView: View {
    var body: some View {
        Text("Recibos pagados")
    }
}

struct RecibosPagadosView_Previews: PreviewProvider {
    static var previews: some View {
        RecibosPagadosView()
    }
}
