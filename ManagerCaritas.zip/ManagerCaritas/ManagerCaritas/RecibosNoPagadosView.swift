//
//  RecibosNoPagadosView.swift
//  ManagerCaritas
//
//  Created by Alumno on 23/11/23.
//

import SwiftUI

struct RecibosNoPagadosView: View {
    var body: some View {
        Text("Recibos no pagados")
    }
}

struct RecibosNoPagadosView_Previews: PreviewProvider {
    static var previews: some View {
        RecibosNoPagadosView()
    }
}
